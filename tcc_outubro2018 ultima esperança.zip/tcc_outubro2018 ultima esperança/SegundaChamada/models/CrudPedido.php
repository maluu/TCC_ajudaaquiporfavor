<?php
require_once 'Conexao.php';
require_once 'Pedido.php';

class CrudPedido
{
    private $conexao;
    public $pedido;

    public function __construct()
    {
        $this->conexao = Conexao::getConexao();
    }

    public function salvar(Pedido $pedido)
    {
        $sql = ("INSERT INTO Pedido (curso,turma,disciplina,professor,dt_inicial,motivo) 
        VALUES ('{$pedido->getCurso()}', '{$pedido->getTurma()}', '{$pedido->getDisciplina()}','{$pedido->getProfessor()}','{$pedido->getData()}', '{$pedido->getMotivo()}')");

        $this->conexao->exec($sql);
    }

    public function editar(Pedido $pedido)
    {
        $sql = "UPDATE pedido set curso = '{$pedido->getCurso()}', turma= '{$pedido->getTurma()}',
        disciplina = '{$pedido->getDisciplina()}',professor = '{$pedido->getProfessor()}', dt_inicial = '{$pedido->getData()}',motivo = '{$pedido->getMotivo()}'  WHERE curso = '{$pedido->getCurso()}'";
        $this->conexao->exec($sql);
    }

    public function getPedidos(){
        $sql = ("SELECT * FROM Pedidos");

        $listaPedidos = $this->conexao->query($sql)->fetchAll(PDO::FETCH_ASSOC);

        $pedidos = [];
        foreach ($listaPedidos as $pedido) {
            $pedidos [] = new Pedido($listaPedidos['motivo'],
                $listaPedidos['dt_inicial'],
                $listaPedidos['cod_pedido'],
                $listaPedidos['curso'],
                $listaPedidos['disciplina'],
                $listaPedidos['turma'],
                $listaPedidos['professor'],
                $listaPedidos['anexo'],
                $listaPedidos['fk_matricula'],
                $listaPedidos['estado'],
                $listaPedidos['descricao']);

        }


    }
}
/*    public function excluir(Pedido $pedido)
    {
        $sql = "DELETE  FROM pedido WHERE cod_pedido ='{$pedido->getcod_pedido}'";
        $this->conexao->exec($sql);
    }
} */