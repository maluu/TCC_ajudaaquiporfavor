<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 22/11/18
 * Time: 15:47
 */
include_once __DIR__."/../models/Turma.php";

class CrudTurma
{
    private $conexao;


    public function __construct(){
        $this->conexao = Conexao::getConexao();
    }

    public function getTurmas(){
        $sql = ("SELECT * FROM turma");

        $listaTurmas = $this->conexao->query($sql)->fetchAll(PDO::FETCH_ASSOC);

        $turmas = [];
        foreach ($listaTurmas as $turma){

            $turmas[] = new Turma($turma['cod_turma'], $turma['cod_curso'], $turma['nome'], $turma['ano']);
        }

        return $turmas;
    }

}