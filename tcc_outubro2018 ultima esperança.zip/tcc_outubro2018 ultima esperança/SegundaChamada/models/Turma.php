<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 22/11/18
 * Time: 15:46
 */

class Turma
{
    private $cod_turma;
    private $cod_curso;
    private $nome;
    private $ano;



    public function __construct($cod_turma, $cod_curso, $cod_nome, $ano){
        $this->cod_turma = $cod_turma;
        $this->cod_curso = $cod_curso;
        $this->cod_nome  = $cod_nome;
        $this->ano       = $ano;
    }

    /**
     * @return mixed
     */
    public function getCodTurma()
    {
        return $this->cod_turma;
    }

    /**
     * @param mixed $cod_turma
     */
    public function setCodTurma($cod_turma)
    {
        $this->cod_turma = $cod_turma;
    }

    /**
     * @return mixed
     */
    public function getCodCurso()
    {
        return $this->cod_curso;
    }

    /**
     * @param mixed $cod_curso
     */
    public function setCodCurso($cod_curso)
    {
        $this->cod_curso = $cod_curso;
    }

    /**
     * @return mixed
     */
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * @param mixed $nome
     */
    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    /**
     * @return mixed
     */
    public function getAno()
    {
        return $this->ano;
    }

    /**
     * @param mixed $ano
     */
    public function setAno($ano)
    {
        $this->ano = $ano;
    }


}